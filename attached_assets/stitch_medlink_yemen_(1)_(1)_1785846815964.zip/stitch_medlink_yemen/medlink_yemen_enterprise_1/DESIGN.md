---
name: MedLink Yemen Enterprise
colors:
  surface: '#faf8ff'
  surface-dim: '#d9d9e5'
  surface-bright: '#faf8ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f3f3fe'
  surface-container: '#ededf9'
  surface-container-high: '#e7e7f3'
  surface-container-highest: '#e1e2ed'
  on-surface: '#191b23'
  on-surface-variant: '#434655'
  inverse-surface: '#2e3039'
  inverse-on-surface: '#f0f0fb'
  outline: '#737686'
  outline-variant: '#c3c6d7'
  surface-tint: '#0053db'
  primary: '#004ac6'
  on-primary: '#ffffff'
  primary-container: '#2563eb'
  on-primary-container: '#eeefff'
  inverse-primary: '#b4c5ff'
  secondary: '#505f76'
  on-secondary: '#ffffff'
  secondary-container: '#d0e1fb'
  on-secondary-container: '#54647a'
  tertiary: '#943700'
  on-tertiary: '#ffffff'
  tertiary-container: '#bc4800'
  on-tertiary-container: '#ffede6'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dbe1ff'
  primary-fixed-dim: '#b4c5ff'
  on-primary-fixed: '#00174b'
  on-primary-fixed-variant: '#003ea8'
  secondary-fixed: '#d3e4fe'
  secondary-fixed-dim: '#b7c8e1'
  on-secondary-fixed: '#0b1c30'
  on-secondary-fixed-variant: '#38485d'
  tertiary-fixed: '#ffdbcd'
  tertiary-fixed-dim: '#ffb596'
  on-tertiary-fixed: '#360f00'
  on-tertiary-fixed-variant: '#7d2d00'
  background: '#faf8ff'
  on-background: '#191b23'
  surface-variant: '#e1e2ed'
typography:
  headline-lg:
    fontFamily: beVietnamPro
    fontSize: 30px
    fontWeight: '700'
    lineHeight: 38px
  headline-md:
    fontFamily: beVietnamPro
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  headline-sm:
    fontFamily: beVietnamPro
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  body-lg:
    fontFamily: beVietnamPro
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: beVietnamPro
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: beVietnamPro
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-lg:
    fontFamily: beVietnamPro
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.02em
  label-md:
    fontFamily: beVietnamPro
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
  headline-lg-mobile:
    fontFamily: beVietnamPro
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  base: 4px
  xs: 4px
  sm: 8px
  md: 16px
  lg: 24px
  xl: 32px
  gutter: 20px
  margin-mobile: 16px
  margin-desktop: 48px
---

## Brand & Style
The design system is engineered for a high-stakes B2B pharmaceutical logistics environment. The brand personality is clinical, authoritative, and ultra-reliable, prioritizing speed of recognition and data integrity.

The visual style follows a **Corporate / Modern** aesthetic with a lean toward **Functional Minimalism**. It utilizes a "White-Label Plus" approach—relying on heavy whitespace, a structured grid, and high-quality medical iconography to instill a sense of institutional trust. The interface is optimized for Right-to-Left (RTL) reading patterns, ensuring that hierarchy and flow are natural for Arabic-speaking pharmacists and procurement officers.

## Colors
The palette is rooted in medical professionalism. The **Primary Blue** (#2563EB) is used for critical actions and navigational anchors. The background is a cool, sterile **Slate-50** (#F8FAFC) to reduce eye strain during long procurement sessions.

- **Primary:** Core actions, active states, and brand presence.
- **Secondary:** Metadata, icons, and non-critical UI elements.
- **Semantic:** Standardized Green (Success), Red (Danger/Shortage), and Amber (Warning/Expiring) are used strictly for status indicators and inventory alerts.
- **Neutral:** A range of Slate grays for borders and secondary text to maintain a clean, structured appearance.

## Typography
This design system uses **Be Vietnam Pro** for its exceptionally clean and modern grotesque structure, which pairs harmoniously with standard modern Arabic system fonts. The typography is scaled for high legibility in data-dense tables.

**Directionality:** All typography must support RTL. In Arabic contexts, ensure line heights are increased by 10-15% compared to English to accommodate character ascenders and descenders. Numerical data (quantities, batch numbers) should remain high-contrast and utilize tabular figures for alignment in price lists and inventory sheets.

## Layout & Spacing
The system utilizes a **Fixed-Fluid Hybrid Grid**. For the main dashboard and catalog, a 12-column grid is used with a maximum container width of 1440px. 

- **Desktop:** 12 columns, 20px gutters, 48px outside margins.
- **Tablet:** 8 columns, 16px gutters, 24px outside margins.
- **Mobile:** 4 columns, 12px gutters, 16px outside margins.

Spacing follows a 4px baseline shift. Large-scale inventory tables should use "Compact" spacing (8px cell padding) to maximize data density, while marketing or onboarding pages should use "Comfortable" spacing (24px+).

## Elevation & Depth
Depth is communicated through **Tonal Layers** and **Low-Contrast Outlines**. Because this is a medical supply tool, heavy shadows are avoided to maintain a "flat" and efficient feel.

- **Level 0 (Base):** #F8FAFC. For the main canvas.
- **Level 1 (Cards):** White surface with a 1px border (#E2E8F0). No shadow. Used for inventory items.
- **Level 2 (Modals/Popovers):** White surface with a soft, 12% opacity Slate shadow (10px blur, 4px Y-offset). 
- **Active State:** Elements being dragged or interacted with receive a subtle primary-colored glow (2px spread, #2563EB at 10% opacity).

## Shapes
The shape language is **Soft (0.25rem)**. This provides a balance between the rigid precision of an enterprise tool and the modern approachability of a healthcare service. 

- **Buttons & Inputs:** 4px (0.25rem) corner radius.
- **Product Cards:** 8px (0.5rem) corner radius.
- **Outer Containers (Modals):** 12px (0.75rem) corner radius.
- **Status Tags:** Fully rounded (pill) for immediate differentiation from clickable buttons.

## Components
- **Buttons:** Primary buttons use solid #2563EB with white text. Secondary buttons use a Slate-100 ghost background. Critical actions (Delete/Cancel) use #EF4444.
- **Product Cards:** Must include a high-res image (Right-aligned in RTL), medication name (Headline-sm), dosage, and a "Quick Add" button. Batch expiry dates must be clearly highlighted.
- **Data Tables:** Zebra-striped rows (#F8FAFC). Sticky headers are mandatory for long SKU lists. The right-most column (in RTL) is reserved for the primary row action.
- **Input Fields:** 1px border (#E2E8F0). On focus, the border changes to Primary Blue with a 1px inset ring. Label alignment must be Right-to-Left.
- **Inventory Chips:** Use color-coded backgrounds for stock levels (e.g., "In Stock" uses light green tint with dark green text).
- **Search Bar:** Centrally located at the top of the supply list, featuring a "Scan Barcode" icon for rapid warehouse entry.