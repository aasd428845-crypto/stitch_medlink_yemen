---
name: Clinical Clarity
colors:
  surface: '#f7f9fb'
  surface-dim: '#d8dadc'
  surface-bright: '#f7f9fb'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f4f6'
  surface-container: '#eceef0'
  surface-container-high: '#e6e8ea'
  surface-container-highest: '#e0e3e5'
  on-surface: '#191c1e'
  on-surface-variant: '#434655'
  inverse-surface: '#2d3133'
  inverse-on-surface: '#eff1f3'
  outline: '#737686'
  outline-variant: '#c3c6d7'
  surface-tint: '#0053db'
  primary: '#004ac6'
  on-primary: '#ffffff'
  primary-container: '#2563eb'
  on-primary-container: '#eeefff'
  inverse-primary: '#b4c5ff'
  secondary: '#565e74'
  on-secondary: '#ffffff'
  secondary-container: '#dae2fd'
  on-secondary-container: '#5c647a'
  tertiary: '#006242'
  on-tertiary: '#ffffff'
  tertiary-container: '#007d55'
  on-tertiary-container: '#bdffdb'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dbe1ff'
  primary-fixed-dim: '#b4c5ff'
  on-primary-fixed: '#00174b'
  on-primary-fixed-variant: '#003ea8'
  secondary-fixed: '#dae2fd'
  secondary-fixed-dim: '#bec6e0'
  on-secondary-fixed: '#131b2e'
  on-secondary-fixed-variant: '#3f465c'
  tertiary-fixed: '#6ffbbe'
  tertiary-fixed-dim: '#4edea3'
  on-tertiary-fixed: '#002113'
  on-tertiary-fixed-variant: '#005236'
  background: '#f7f9fb'
  on-background: '#191c1e'
  surface-variant: '#e0e3e5'
typography:
  headline-lg:
    fontFamily: Be Vietnam Pro
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Be Vietnam Pro
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
  headline-md:
    fontFamily: Be Vietnam Pro
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  headline-sm:
    fontFamily: Be Vietnam Pro
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  body-lg:
    fontFamily: Be Vietnam Pro
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Be Vietnam Pro
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Be Vietnam Pro
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-md:
    fontFamily: Be Vietnam Pro
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
  label-sm:
    fontFamily: Be Vietnam Pro
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 4px
  xs: 4px
  sm: 8px
  md: 16px
  lg: 24px
  xl: 32px
  gutter: 20px
  margin-mobile: 16px
  margin-desktop: 48px
---

## Brand & Style
The design system is engineered for the high-stakes B2B pharmaceutical landscape in Yemen. It balances enterprise-grade reliability with a modern, medical aesthetic. The personality is authoritative yet accessible, prioritizing speed of task completion and visual trust.

The design style utilizes **Corporate Modernism** with a **Tactile** edge. This means ultra-clean layouts, significant whitespace, and professional blue accents, combined with soft-depth containers that make digital medical supplies feel tangible and organized. The UI is specifically optimized for RTL (Right-to-Left) reading patterns to serve the local Yemeni market effectively.

## Colors
The palette is rooted in medical professionalism. 
- **Primary Blue (#2563EB):** Used for primary actions, navigation markers, and brand-critical elements. It signifies trust and hygiene.
- **Deep Navy (#0F172A):** Used for typography and iconography to provide maximum contrast against light backgrounds.
- **Success Green (#10B981):** Represents health, safety, and available stock.
- **Neutral (#F8FAFC):** The primary background color to reduce eye strain during long procurement sessions.

Color application must prioritize high contrast ratios for readability in varied lighting conditions common in pharmaceutical warehouses.

## Typography
**Be Vietnam Pro** is selected for its contemporary geometric construction and exceptional legibility in both English and Arabic-equivalent scripts. 

- **Hierarchy:** Use bold weights for headlines to establish a clear information architecture. 
- **RTL Optimization:** Line heights are slightly increased (1.5x - 1.6x) to accommodate Arabic script descenders and ensure pharmaceutical names are never cramped.
- **Readability:** Body text uses a slightly darkened slate color rather than pure black to prevent visual vibration on bright screens.

## Layout & Spacing
The layout follows a **Fluid Grid** system based on an 8px rhythm. 

- **Desktop:** 12-column grid with a maximum container width of 1440px. 24px gutters.
- **Tablet:** 8-column grid with 20px gutters.
- **Mobile:** 4-column grid with 16px gutters and margins.

Spacing should be generous to maintain a "clean" medical feel. Group related pharmaceutical data (SKU, Price, Expiry) using `spacing.sm`, while separating distinct product cards with `spacing.lg`. For RTL layouts, all horizontal spacing logic is mirrored.

## Elevation & Depth
This design system uses **Tonal Layers** combined with **Ambient Shadows** to create a sense of organized hierarchy.

- **Level 0 (Background):** #F8FAFC.
- **Level 1 (Cards/Surface):** White (#FFFFFF) with a very soft, diffused shadow (0px 4px 12px rgba(15, 23, 42, 0.05)).
- **Level 2 (Dropdowns/Modals):** White (#FFFFFF) with a more pronounced elevation shadow (0px 12px 32px rgba(15, 23, 42, 0.1)).

Borders are used sparingly, primarily as low-contrast separators (#E2E8F0) rather than structural containers.

## Shapes
The shape language is **Rounded**, conveying friendliness and approachability within a sterile environment. 

- **Standard Buttons & Inputs:** 0.5rem (8px) corner radius.
- **Large Containers/Cards:** 1rem (16px) corner radius.
- **Product Badges/Chips:** Full pill-shaped (100px).

Avoid sharp 0px corners to distance the product from "legacy" enterprise software, ensuring a modern user experience.

## Components
- **Buttons:** Primary buttons use a solid #2563EB fill with white text. Secondary buttons use a #2563EB outline. Use `label-md` for button text.
- **Input Fields:** White background, 1px #E2E8F0 border. On focus, the border transitions to 2px #2563EB with a subtle blue glow.
- **Medical Chips:** Used for "In Stock", "Prescription Required", or "Cold Chain". These are pill-shaped with light tinted backgrounds (e.g., light green background for Success Green text).
- **Product Cards:** Must include a clear thumbnail, name in `headline-sm`, and price in `primary_color_hex`. 
- **Inventory Lists:** Use Zebra-striping (Level 0 and White) for high-density data tables to ensure row-tracking across the screen.
- **Icons:** Use linear, medium-stroke icons. Medical-specific icons (crosses, capsules, hospitals) should be consistent in weight with the typography.