---
name: Ethos Medical
colors:
  surface: '#f8f9ff'
  surface-dim: '#d0dbed'
  surface-bright: '#f8f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eff4ff'
  surface-container: '#e6eeff'
  surface-container-high: '#dee9fc'
  surface-container-highest: '#d9e3f6'
  on-surface: '#121c2a'
  on-surface-variant: '#424752'
  inverse-surface: '#27313f'
  inverse-on-surface: '#eaf1ff'
  outline: '#727784'
  outline-variant: '#c2c6d4'
  surface-tint: '#115cb9'
  primary: '#003f87'
  on-primary: '#ffffff'
  primary-container: '#0056b3'
  on-primary-container: '#bbd0ff'
  inverse-primary: '#acc7ff'
  secondary: '#526069'
  on-secondary: '#ffffff'
  secondary-container: '#d3e2ed'
  on-secondary-container: '#56656e'
  tertiary: '#004c32'
  on-tertiary: '#ffffff'
  tertiary-container: '#006645'
  on-tertiary-container: '#5ae8ac'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#d7e2ff'
  primary-fixed-dim: '#acc7ff'
  on-primary-fixed: '#001a40'
  on-primary-fixed-variant: '#004491'
  secondary-fixed: '#d6e5ef'
  secondary-fixed-dim: '#bac9d3'
  on-secondary-fixed: '#0f1d25'
  on-secondary-fixed-variant: '#3b4951'
  tertiary-fixed: '#6ffbbe'
  tertiary-fixed-dim: '#4edea3'
  on-tertiary-fixed: '#002113'
  on-tertiary-fixed-variant: '#005236'
  background: '#f8f9ff'
  on-background: '#121c2a'
  surface-variant: '#d9e3f6'
typography:
  display-lg:
    fontFamily: Amiri
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 60px
  headline-lg:
    fontFamily: Amiri
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 44px
  headline-lg-mobile:
    fontFamily: Amiri
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
  headline-md:
    fontFamily: Amiri
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 34px
  body-lg:
    fontFamily: Amiri
    fontSize: 20px
    fontWeight: '400'
    lineHeight: 32px
  body-md:
    fontFamily: Amiri
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  label-md:
    fontFamily: Work Sans
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
    letterSpacing: 0.02em
  caption:
    fontFamily: Amiri
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  unit: 4px
  xs: 4px
  sm: 8px
  md: 16px
  lg: 24px
  xl: 48px
  gutter: 24px
  margin-mobile: 16px
  margin-desktop: 64px
---

## Brand & Style
The design system is engineered for a high-trust, enterprise medical environment, specifically tailored for the Yemeni healthcare landscape. The brand personality is **authoritative, traditional, and impeccably professional**, bridging the gap between modern clinical efficiency and classical scholarly heritage.

The style is **Corporate / Modern** with a focus on high legibility and structured information density. It evokes an emotional response of reliability and cultural resonance, ensuring that medical professionals feel both the precision of the technology and the weight of their clinical responsibility. The UI utilizes ample whitespace and a systematic hierarchy to reduce cognitive load in high-stress medical environments.

## Colors
The palette is centered around a **Professional Blue**, symbolizing trust and clinical precision. 

- **Primary (#0056B3):** Used for primary actions, active states, and structural branding.
- **Secondary (#E3F2FD):** A light tint used for subtle backgrounds, surface highlighting, and high-frequency soft UI elements.
- **Tertiary (#10B981):** Reserved for "Success" states and vital sign indicators.
- **Neutral (#1F2937):** A deep charcoal for text and high-contrast borders to ensure maximum legibility against the light background.

The system defaults to a **Light Mode** to mirror the bright, clean environment of a clinical facility, utilizing "Medical White" (#FFFFFF) as the foundational surface color.

## Typography
This design system prioritizes a **Classical Arabic Aesthetic** to convey authority and scholarly tradition. **Amiri** is utilized for both headlines and body text to provide a literary and prestigious feel, essential for medical documentation and formal enterprise communication.

- **Headlines:** Use Bold weights of Amiri. These should feel like traditional manuscripts—authoritative and grounded.
- **Body Text:** Use Regular weights. Amiri requires slightly larger font sizes (18px-20px) compared to Latin fonts to ensure the intricate calligraphic details and diacritics remain legible at all times.
- **Functional Labels:** **Work Sans** is used sparingly for small-scale UI labels (like button text or metadata) where a neutral, sans-serif clarity is required for rapid scanning.
- **RTL Optimization:** All typographic alignments must default to Right-to-Left, ensuring line heights are generous enough to prevent overlapping of ascenders and descenders in the Arabic script.

## Layout & Spacing
The layout follows a **Fixed Grid** philosophy for desktop to maintain a structured, "ledger-like" appearance for patient records and data tables.

- **Desktop:** A 12-column grid with 24px gutters. Max content width is 1280px.
- **Mobile:** A 4-column fluid grid with 16px margins.
- **RTL Logic:** Spacing and layout directions are mirrored. Margins that appear on the left in LTR designs must be applied to the right. 

A strict **4px baseline grid** is used to ensure all components and typography align perfectly, creating a sense of mathematical order and clinical accuracy.

## Elevation & Depth
The design system uses **Tonal Layers** rather than heavy shadows to signify hierarchy. This maintains a clean, sterile aesthetic suitable for medical software.

1.  **Level 0 (Base):** #FFFFFF – The main canvas.
2.  **Level 1 (Surface):** #F9FAFB – Used for sidebar navigation and secondary content areas.
3.  **Level 2 (Elevated):** Subtle, low-opacity shadows (Blur: 8px, Y: 2px, Color: #000000 5%) are used exclusively for floating elements like Modals or Dropdowns.

Contrast is achieved through 1px borders using a light neutral grey (#E5E7EB) to define containers, rather than relying on shadow depth.

## Shapes
A **Rounded** shape language is applied across the system to soften the "clinical" feel and make the enterprise software feel more approachable for daily use.

- **Base Radius:** 0.5rem (8px) for buttons, input fields, and small cards.
- **Large Radius:** 1rem (16px) for main containers and dashboard widgets.
- **Full Radius:** Used for status badges and circular iconography.

This roundedness balances the traditional, sharp serifs of the typography, creating a harmonious blend of old-world authority and modern software design.

## Components
- **Buttons:** Primary buttons use the Primary Blue with white text. They should have a minimum height of 48px to accommodate the taller Amiri script comfortably.
- **Input Fields:** Use a 1px #E5E7EB border that shifts to Primary Blue on focus. Label text remains pinned to the top right of the field.
- **Cards:** White background with a 1px light border and 16px padding. Used to group patient data and clinical observations.
- **Status Chips:** Use highly saturated versions of Tertiary (Green) for "Healthy/Stable" and soft red for "Critical." Text inside chips should use the Label-MD style.
- **Data Tables:** High density with alternating row colors (#F9FAFB) and clear 1px horizontal dividers. Headers must be bold and clearly distinguish between different data types (e.g., Patient ID vs. Diagnosis).
- **Patient Timeline:** A vertical line component using Primary Blue to track medical history, using circular nodes to indicate specific health events.