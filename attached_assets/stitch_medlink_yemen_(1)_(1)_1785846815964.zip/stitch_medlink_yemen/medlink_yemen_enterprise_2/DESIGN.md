---
name: MedLink Yemen Enterprise
colors:
  surface: '#f9f9fc'
  surface-dim: '#dadadc'
  surface-bright: '#f9f9fc'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f3f3f6'
  surface-container: '#eeeef0'
  surface-container-high: '#e8e8ea'
  surface-container-highest: '#e2e2e5'
  on-surface: '#1a1c1e'
  on-surface-variant: '#424752'
  inverse-surface: '#2f3133'
  inverse-on-surface: '#f0f0f3'
  outline: '#727783'
  outline-variant: '#c2c6d4'
  surface-tint: '#005db6'
  primary: '#00478d'
  on-primary: '#ffffff'
  primary-container: '#005eb8'
  on-primary-container: '#c8daff'
  inverse-primary: '#a9c7ff'
  secondary: '#006970'
  on-secondary: '#ffffff'
  secondary-container: '#7af1fc'
  on-secondary-container: '#006e75'
  tertiary: '#43484c'
  on-tertiary: '#ffffff'
  tertiary-container: '#5b6063'
  on-tertiary-container: '#d6dade'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#d6e3ff'
  primary-fixed-dim: '#a9c7ff'
  on-primary-fixed: '#001b3d'
  on-primary-fixed-variant: '#00468c'
  secondary-fixed: '#7df4ff'
  secondary-fixed-dim: '#5dd8e2'
  on-secondary-fixed: '#002022'
  on-secondary-fixed-variant: '#004f54'
  tertiary-fixed: '#dfe3e7'
  tertiary-fixed-dim: '#c3c7cb'
  on-tertiary-fixed: '#171c1f'
  on-tertiary-fixed-variant: '#43474b'
  background: '#f9f9fc'
  on-background: '#1a1c1e'
  surface-variant: '#e2e2e5'
typography:
  headline-lg:
    fontFamily: Outfit
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Outfit
    fontSize: 26px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Outfit
    fontSize: 24px
    fontWeight: '500'
    lineHeight: 32px
  headline-sm:
    fontFamily: Outfit
    fontSize: 20px
    fontWeight: '500'
    lineHeight: 28px
  body-lg:
    fontFamily: ibmPlexSans
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: ibmPlexSans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: ibmPlexSans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-md:
    fontFamily: ibmPlexSans
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.05em
  label-sm:
    fontFamily: ibmPlexSans
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.05em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 8px
  gutter-sm: 12px
  gutter-md: 16px
  margin-mobile: 16px
  margin-desktop: 32px
  container-max: 1280px
---

## Brand & Style
The design system is engineered for a high-end medical logistics environment operating in Yemen. The brand personality is **Precise, Vital, and Institutional**. It balances the urgency of medical supply chains with the clinical reliability of healthcare services.

The visual style follows a **Modern Corporate** aesthetic with a lean toward **Minimalism**. It prioritizes extreme clarity and high-quality whitespace to reduce cognitive load for logistics coordinators and healthcare providers. The interface uses a systematic approach to depth and structure, ensuring a professional and trustworthy experience that feels technologically advanced yet culturally grounded.

## Colors
The palette is rooted in medical professionalism. The **Primary Color** is a deep, clinical blue used for core actions and brand presence. The **Secondary Color** is a teal-leaning cyan, representing innovation and pharmaceutical precision, used for success states and accent information. 

The **Tertiary Color** provides a soft background for container nesting to avoid the harshness of pure white. **Neutrals** are slightly cooled to maintain a modern, technical feel across typography and borders.

## Typography
This design system utilizes a high-performance pairing of **Outfit** for headlines and **IBM Plex Sans** (with Arabic support) for body and UI elements. This combination ensures a tech-forward "startup" energy in titles while maintaining an "enterprise-grade" functional feel for data-heavy views.

For the Arabic implementation, ensure **IBM Plex Sans Arabic** is utilized to match the stroke weight of the English Latin characters. For mobile devices, headline sizes scale down to prevent awkward line breaks in narrow containers, while body text remains at a legible 16px minimum for critical medical data. All labels use a slightly increased letter-spacing and medium weights to ensure clarity in dense logistics dashboards.

## Layout & Spacing
The layout follows a **Fixed-Fluid Hybrid** model. Content is contained within a maximum width of 1280px on desktop to maintain readability, while mobile views utilize a flexible 4-column grid with 16px margins.

Spacing is based on an **8px linear scale**, ensuring mathematical harmony across all components. High-density views (such as inventory lists) may switch to a 4px "compact" sub-grid. In the context of Yemen's logistics, the layout must remain functional even on lower-resolution mobile devices, prioritizing vertical stacks over horizontal scrolling.

## Elevation & Depth
Depth is communicated through **Tonal Layers** and extremely subtle **Ambient Shadows**. Instead of heavy shadows, the system uses "Surface Containers"—subtle shifts in background gray (Tertiary Color) to denote hierarchy.

Elevated elements like Modals or Floating Action Buttons use a 12% opacity shadow with a 16px blur, tinted with the Primary Blue to maintain a cohesive atmosphere. Borders are 1px thick and use a low-contrast neutral color, creating a "ghost border" effect that feels clean and unobtrusive.

## Shapes
The shape language is **Rounded**, using a 0.5rem (8px) base radius. This softening of the UI helps humanize the clinical nature of the application. High-level containers like cards use `rounded-lg` (16px), while utility components like input fields and small buttons use the base 8px. This consistency creates a safe, approachable environment for users handling high-stress logistics tasks.

## Components
- **Buttons:** Primary buttons use a solid fill of the Primary Color with white Outfit SemiBold text. Secondary buttons are outlined with a 1.5px stroke.
- **Input Fields:** Use a 1px Neutral-300 border that thickens to 2px Primary on focus. Labels sit 4px above the input in `label-md`.
- **Cards:** White background with a 1px Neutral-100 border and no shadow. Use `rounded-lg` for all external corners.
- **Chips:** Used for "Status" (In-Transit, Delivered, Pending). They feature a light background tint of the status color with high-contrast text.
- **Lists:** High-density medical inventory lists use `body-sm` for secondary info and `body-md` for item names, separated by 1px dividers.
- **Data Tables:** Essential for logistics. Use a sticky header with a slightly darker Tertiary background and `label-sm` for column headers.