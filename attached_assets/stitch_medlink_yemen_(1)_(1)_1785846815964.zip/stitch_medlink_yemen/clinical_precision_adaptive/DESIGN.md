---
name: Clinical Precision Adaptive
colors:
  surface: '#faf8ff'
  surface-dim: '#d9d9e5'
  surface-bright: '#faf8ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f3f3fe'
  surface-container: '#ededf9'
  surface-container-high: '#e7e7f3'
  surface-container-highest: '#e1e2ed'
  on-surface: '#191b23'
  on-surface-variant: '#434655'
  inverse-surface: '#2e3039'
  inverse-on-surface: '#f0f0fb'
  outline: '#737686'
  outline-variant: '#c3c6d7'
  surface-tint: '#0053db'
  primary: '#004ac6'
  on-primary: '#ffffff'
  primary-container: '#2563eb'
  on-primary-container: '#eeefff'
  inverse-primary: '#b4c5ff'
  secondary: '#505f76'
  on-secondary: '#ffffff'
  secondary-container: '#d0e1fb'
  on-secondary-container: '#54647a'
  tertiary: '#943700'
  on-tertiary: '#ffffff'
  tertiary-container: '#bc4800'
  on-tertiary-container: '#ffede6'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dbe1ff'
  primary-fixed-dim: '#b4c5ff'
  on-primary-fixed: '#00174b'
  on-primary-fixed-variant: '#003ea8'
  secondary-fixed: '#d3e4fe'
  secondary-fixed-dim: '#b7c8e1'
  on-secondary-fixed: '#0b1c30'
  on-secondary-fixed-variant: '#38485d'
  tertiary-fixed: '#ffdbcd'
  tertiary-fixed-dim: '#ffb596'
  on-tertiary-fixed: '#360f00'
  on-tertiary-fixed-variant: '#7d2d00'
  background: '#faf8ff'
  on-background: '#191b23'
  surface-variant: '#e1e2ed'
typography:
  display-lg:
    fontFamily: Be Vietnam Pro
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Be Vietnam Pro
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
  headline-lg-mobile:
    fontFamily: Be Vietnam Pro
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  title-md:
    fontFamily: Be Vietnam Pro
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
  body-md:
    fontFamily: Be Vietnam Pro
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-sm:
    fontFamily: Be Vietnam Pro
    fontSize: 13px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.01em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 4px
  xs: 4px
  sm: 8px
  md: 16px
  lg: 24px
  xl: 40px
  container-max: 1440px
  gutter: 24px
---

## Brand & Style
The design system facilitates a high-stakes enterprise healthcare environment. The brand personality is clinical, efficient, and authoritative, prioritizing cognitive load reduction for medical professionals. 

The aesthetic is a refined **Corporate Modern** style with a focus on multi-modal adaptability. It utilizes a layered surface architecture that transitions seamlessly between three distinct environmental modes:
1.  **Light Mode:** For high-glare clinical settings and daytime administrative work.
2.  **Dark Mode:** A deep charcoal palette for reduced eye strain during extended night shifts.
3.  **Midnight Mode:** A pure black, high-contrast interface optimized for OLED mobile devices and low-light diagnostic environments.

The emotional response should be one of absolute reliability and clarity, achieved through generous whitespace, precise alignment, and a strict hierarchy of information.

## Colors
The system employs a dynamic color mapping strategy to maintain WCAG 2.1 accessibility across all three themes.

- **Primary Blue:** Adjusts from a robust #2563EB in Light mode to a more luminous #60A5FA in Midnight mode to ensure the stroke remains legible against pure black without causing "vibration" or haloing.
- **Surface Strategy:** 
    - **Light:** Uses subtle grey backgrounds to distinguish the canvas from white containers.
    - **Dark:** Uses a #121212 base with slightly lighter #1E1E1E containers to denote elevation.
    - **Midnight:** Uses a #000000 base for maximum battery efficiency on OLED, with #121212 used sparingly for secondary elevation levels.
- **Status Colors:** Success (Emerald), Warning (Amber), and Error (Rose) must be desaturated by 10-15% when moving from Light to Midnight mode to maintain visual comfort.

## Typography
**Be Vietnam Pro** is the exclusive typeface, chosen for its exceptional legibility in dense data environments. 

- **Weight Usage:** Use Medium (500) for labels and Semi-Bold (600) for titles to ensure they don't "thin out" visually against dark backgrounds.
- **Contrast Ratios:** In Midnight mode, body text should utilize a slightly off-white (#F1F5F9) rather than pure white to reduce eye fatigue, while headings remain pure white for maximum impact.
- **Readability:** Maintain a strict 1.5x line height for body text to assist medical professionals in scanning long patient records or clinical notes.

## Layout & Spacing
The system utilizes a **4px baseline grid** to ensure mathematical precision in clinical charts and dashboards.

- **Desktop:** 12-column fluid grid with 24px gutters. Sidebars for navigation are fixed at 280px.
- **Tablet:** 8-column grid with 16px gutters.
- **Mobile:** 4-column grid with 16px margins.
- **Density:** Provide a "Compact" spacing mode for data-heavy tables where the `md` spacing token (16px) is reduced to 12px for row heights.

## Elevation & Depth
The system uses **Tonal Layering** supplemented by subtle shadows.

- **Light Mode:** Uses soft, diffused shadows (0px 4px 12px rgba(0,0,0,0.05)) to separate floating cards from the background.
- **Dark/Midnight Mode:** Shadows are largely ineffective. Depth is communicated through **Surface Tints**. Elements with higher elevation are represented by lighter surface colors (e.g., Background #000000 -> Card #121212 -> Modal #1E1E1E).
- **Outlines:** In Midnight mode, use a 1px border of `border` (#1E293B) to define element boundaries where tonal separation is insufficient.

## Shapes
The shape language is consistent across all themes: **Rounded (0.5rem / 8px)**.

- **Buttons & Inputs:** Fixed 8px radius.
- **Cards & Modals:** Use `rounded-lg` (16px) for larger containers.
- **Status Dots:** Purely circular (9999px).
- **Selection Indicators:** Use a 4px vertical bar on the left side of active list items or sidebar links to provide a high-visibility clear state indicator.

## Components
- **Buttons:**
    - Primary: Filled with Primary Color, white text.
    - Secondary: Outlined in Light mode; Ghost/Subtle-fill in Midnight mode to avoid overwhelming visual noise.
- **Input Fields:**
    - Backgrounds must match the `surface` token. 
    - Focused state uses a 2px Primary Color border.
- **Chips:** Used for patient status or medical tags. In Dark/Midnight modes, chips use a low-opacity primary background (15% opacity) with a high-contrast text color.
- **Data Tables:**
    - Use zebra-striping in Light mode. 
    - Use thin #334155 borders and no striping in Midnight mode to maintain OLED "true black" benefits.
- **Cards:** 
    - High-level summaries (Vital signs, Alerts). In Midnight mode, these should have a 1px border to ensure the "true black" background doesn't merge with the app chrome.